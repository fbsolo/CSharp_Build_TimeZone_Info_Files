﻿using System;
using System.IO;

namespace CSharp_Build_TimeZone_Info_Files
{
        class Program
    {
        public static int numericDayOfWeek(string dayOfWeekString)
        {
            //  This function maps a day of week string ("Sunday", "Monday", etc.)
            //  into its 0 to 6 numeric equivalent. The original TSqlToolbox tables
            //  used this number range for the
            //
            //      DateTimeUtil.TimeZoneAdjustmentRule.DaylightTransitionStartDayOfWeek
            //      DateTimeUtil.TimeZoneAdjustmentRule.DaylightTransitionEndDayOfWeek
            //
            //  values.

            int retVal = -1;

            switch (dayOfWeekString)
            {
                case "Sunday":
                    retVal = 0;
                    break;
                case "Monday":
                    retVal = 1;
                    break;
                case "Tuesday":
                    retVal = 2;
                    break;
                case "Wednesday":
                    retVal = 3;
                    break;
                case "Thursday":
                    retVal = 4;
                    break;
                case "Friday":
                    retVal = 5;
                    break;
                case "Saturday":
                    retVal = 6;
                    break;
            }
            return retVal;
        }

        static void Main(string[] args)
            {
                TimeZoneInfo.AdjustmentRule[] adjustments;
                string targetDirectory = "C:\\TSQL_TOOLBOX_UPDATE\\TEXT_FILES";
                string timeZoneAdjustmentString = "";
                string timeZoneString = "";
                int timeZoneAdjustmentRuleNumber;
                int timeZoneAdjustmentIDVal = 1;
                int timeZoneIDVal = 1;

                //  In the outer foreach loop, build a
                //
                //      timeZoneString
                //
                //  string of time zone information sourced
                //  from the Windows registry. Each foreach
                //  iteration covers one time zone. Use a
                //
                //      " | "
                //
                //  delimiter between the values, because some
                //  of the returned values have embedded commas.
                //  This means that data for a CSV file would
                //  need more "cleaning". For a numeric ID column,
                //  use an integer for the first column, starting
                //  at 1 and incrementing. Add a newline at the
                //  end of each finished time zone. The timeZoneString
                //  variable accumulates for all detected time zones.

                foreach (TimeZoneInfo z in TimeZoneInfo.GetSystemTimeZones())
                {
                    timeZoneString += timeZoneIDVal.ToString();
                    timeZoneString += "|";
                    timeZoneString += z.Id;
                    timeZoneString += "|";
                    timeZoneString += z.StandardName;
                    timeZoneString += "|";
                    timeZoneString += z.DisplayName;
                    timeZoneString += "|";
                    timeZoneString += z.DaylightName;
                    timeZoneString += "|";

                    //  Convert the boolean
                    //
                    //      z.SupportsDaylightSavingTime
                    //
                    //  value to a bit-style integer
                    //  because BULK INSERT will depend
                    //  on this value type

                    timeZoneString += z.SupportsDaylightSavingTime ? 1 : 0;
                    timeZoneString += "|";
                    timeZoneString += z.BaseUtcOffset.TotalSeconds.ToString();
                    timeZoneString += Environment.NewLine;

                    //  https://docs.microsoft.com/en-us/dotnet/api/system.timezoneinfo.adjustmentrule?view=netframework-4.8

                    //  For this specific z (TimeZoneInfo) value,
                    //  build an array of adjustments

                    adjustments = z.GetAdjustmentRules();

                    //  Reset the rule number for the new set of adjustment
                    //  rules in the inner foreach loop.

                    timeZoneAdjustmentRuleNumber = 1;

                    //  In the inner foreach loop, build a
                    //
                    //      timeZoneAdjustmentString
                    //
                    //  string of time zone adjustment information
                    //  sourced from the Windows registry. Each foreach
                    //  iteration covers one time zone adjustment.
                    //  Use a
                    //
                    //      " | "
                    //
                    //  delimiter between the values, to keep it consistent
                    //  with the outer loop. Future adjustments might
                    //  have commas. Also, this means that data for a
                    //  CSV file would need more "cleaning". Add a newline
                    //  at the end of each finished time zone adjustment.
                    //  The timeZoneAdjustmentString variable accumulates
                    //  for all detected time zones.

                    foreach (TimeZoneInfo.AdjustmentRule adjustment in adjustments)
                    {
                        timeZoneAdjustmentString += timeZoneAdjustmentIDVal.ToString();
                        timeZoneAdjustmentString += "|";

                        //  Use the timeZoneIDVal, as set in the outer foreach
                        //  loop, to tie the adjustments built in this loop with
                        //  the time zone (timeZoneIDVal) that owns them.

                        timeZoneAdjustmentString += timeZoneIDVal.ToString();
                        timeZoneAdjustmentString += "|";

                        timeZoneAdjustmentString += timeZoneAdjustmentRuleNumber.ToString();

                        //  Increment ruleNumber for each detected adjustment rule.

                        timeZoneAdjustmentRuleNumber += 1;

                        timeZoneAdjustmentString += "|";
                        timeZoneAdjustmentString += adjustment.DateStart.ToString();
                        timeZoneAdjustmentString += "|";
                        timeZoneAdjustmentString += adjustment.DateEnd.ToString();
                        timeZoneAdjustmentString += "|";

                        //  Convert the booleans
                        //
                        //      adjustment.DaylightTransitionStart.IsFixedDateRule
                        //      adjustment.DaylightTransitionEnd.IsFixedDateRule
                        //
                        //  values to bit-style integer because
                        //  BULK INSERT will depend on this
                        //  value type

                        timeZoneAdjustmentString += adjustment.DaylightTransitionStart.IsFixedDateRule ? 1 : 0;

                        timeZoneAdjustmentString += "|";
                        timeZoneAdjustmentString += adjustment.DaylightTransitionStart.Month.ToString();
                        timeZoneAdjustmentString += "|";
                        timeZoneAdjustmentString += adjustment.DaylightTransitionStart.Day.ToString();
                        timeZoneAdjustmentString += "|";
                        timeZoneAdjustmentString += adjustment.DaylightTransitionStart.Week.ToString();
                        timeZoneAdjustmentString += "|";

                        //  Start with
                        //
                        //      adjustment.DaylightTransitionStart.DayOfWeek
                        //
                        //  and convert to a numeric day-of-week value (0 - 6)
                        //  because the
                        //
                        //      TSqlToolbox.DateTimeUtil.TimezoneAdjustmentRule.DaylightTransitionStartDayOfWeek
                        //
                        //  column has an int data type

                        timeZoneAdjustmentString += numericDayOfWeek(adjustment.DaylightTransitionStart.DayOfWeek.ToString());
                        timeZoneAdjustmentString += "|";
                        
                        //  Use HH in the TimeOfDay format string to build a 24-hour clock time value

                        timeZoneAdjustmentString += adjustment.DaylightTransitionStart.TimeOfDay.ToString("HH:mm:ss.ffffff");
                        timeZoneAdjustmentString += "|";
                        timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.IsFixedDateRule ? 1 : 0;
                        timeZoneAdjustmentString += "|";
                        timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.Month.ToString();
                        timeZoneAdjustmentString += "|";
                        timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.Day.ToString();
                        timeZoneAdjustmentString += "|";
                        timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.Week.ToString();
                        timeZoneAdjustmentString += "|";

                        //  Start with
                        //
                        //      adjustment.DaylightTransitionEnd.DayOfWeek
                        //
                        //  and convert to a numeric day-of-week value (0 - 6)
                        //  because the
                        //
                        //      TSqlToolbox.DateTimeUtil.TimezoneAdjustmentRule.DaylightTransitionEndDayOfWeek
                        //
                        //  column has an int data type

                        timeZoneAdjustmentString += numericDayOfWeek(adjustment.DaylightTransitionEnd.DayOfWeek.ToString());
                        timeZoneAdjustmentString += "|";

                        //  Use HH in the TimeOfDay format string to build a 24-hour clock time value

                        timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.TimeOfDay.ToString("HH:mm:ss.ffffff");
                        timeZoneAdjustmentString += "|";
                        timeZoneAdjustmentString += adjustment.DaylightDelta.TotalSeconds.ToString();
                        timeZoneAdjustmentString += Environment.NewLine;

                        //  Increment timeZoneAdjustmentIDVal for the next time zone adjustment

                        timeZoneAdjustmentIDVal += 1;
                    }

                    //  Increment timeZoneIDVal for the next time zone

                    timeZoneIDVal += 1;
                }

                //  Remove the ending Environment.Newline characters

                timeZoneAdjustmentString = timeZoneAdjustmentString.Substring(0, (timeZoneAdjustmentString.Length - 2));
                timeZoneString = timeZoneString.Substring(0, (timeZoneString.Length - 2));

                //  Build the
                //
                //       C:\TSQL_TOOLBOX_UPDATE\TEXT_FILES
                //
                //  directory. Remember to escape
                //  the file path backslashes in the
                //  targetDirectory variable (done above).

                if (!Directory.Exists(targetDirectory))
                {
                    Directory.CreateDirectory(targetDirectory);
                }

                //  Build the
                //
                //      timeZoneFile
                //      timeZoneAdjustmentFile
                //
                //  files in the targetDirectory directory.

                File.WriteAllText(targetDirectory + "\\timeZoneFile", timeZoneString);
                File.WriteAllText(targetDirectory + "\\timeZoneAdjustmentFile", timeZoneAdjustmentString);
            }

        }
}